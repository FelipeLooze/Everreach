# Everreach — Flora ampliada (versão 2)

## Resumo

- 500 espécies anteriores preservadas integralmente (mesmos IDs e conteúdo por registro).
- 1.000 espécies novas, identificadas de `EV-FL-0501` a `EV-FL-1500`.
- **1.500 espécies no total**, das quais **1108 são flores**.
- **3.000 itens de coleta** (2 por espécie), com IDs `IT-EVR-FL-####-P##`.
- 10 biomas, os mesmos do bestiário; os tipos permanecem nos 12 enums já definidos.
- Chances de drop, valores econômicos, janelas e regeneração são **propostas**, não parâmetros calibrados no playtest.

## Distribuição por bioma

| Bioma | Total | Novas |
|---|---:|---:|
| arredores_povoados | 135 | 90 |
| planicies_cultivos | 205 | 140 |
| bosques_florestas | 280 | 190 |
| rios_lagos | 150 | 100 |
| pantanos_mangues | 135 | 90 |
| colinas_montanhas | 185 | 130 |
| cavernas_subterraneo | 75 | 50 |
| ruinas_estruturas | 100 | 70 |
| costa | 135 | 80 |
| regioes_frias | 100 | 60 |

## Distribuição por tipo

| Tipo | Total |
|---|---:|
| alga | 20 |
| arbusto | 54 |
| arvore | 51 |
| erva | 74 |
| flor | 1108 |
| fungo | 38 |
| graminea | 23 |
| junco | 20 |
| liquen | 27 |
| musgo | 49 |
| samambaia | 19 |
| trepadeira | 17 |

## Como usar

1. Para substituir o catálogo antigo, use **somente** `Everreach_Flora_1500_Especies_Completo_v2.json`.
2. Para importar apenas as novas espécies, use `Everreach_Flora_1000_Novas_Especies_v2.json`; nunca importar os dois no mesmo banco.
3. O arquivo de índice é apenas para consulta; **não** é a fonte autoritativa.
4. Não surgem novas plantas no mapa apenas porque o JSON foi instalado. É necessário gerar e persistir nós em locais acessíveis.
5. O backend define coleta, quantidade, disponibilidade, deterioração, preços e recompensas. O narrador descreve os eventos validados.
6. A expansão não altera automaticamente o Diretor de Missões nem o catálogo dos compradores. Os itens novos precisam ser vinculados conforme regras reais do código.
7. Usos botânicos são **possibilidades narrativas/comerciais**, nunca efeitos médicos ou consumíveis automáticos.

## Validação

- 19 verificações estruturais aprovadas de 19.
- IDs de espécie, item e parte únicos; nenhuma colisão com bestiário.
- Nomes únicos após normalização de acentos e caixa.
- Biomas, tipos, métodos e ferramentas conforme os enums do arquivo de origem.
- Partes e itens pareados por ID e origem.
- 500 espécies e 1.000 itens existentes preservados, byte a byte após serialização de cada registro.
- Compatibilidade com código real do backend **ainda não testada**.

## Arquivos

- `Everreach_Flora_1500_Especies_Completo_v2.json`: substitui a flora antiga.
- `Everreach_Flora_1000_Novas_Especies_v2.json`: somente os registros adicionados.
- `Everreach_Flora_1500_Indice_Leve_v2.json`: índice para inspeção.
- `Everreach_Flora_1500_Guia_Validacao_v2.md`: este guia.
