# Everreach — Bestiário 500 (25/10/2026)

## Resultado

- **500 monstros** distribuídos igualmente: 100 por nível, de 1 a 5.
- **250 criaturas novas** e **750 novos registros de saque**.
- **810 materiais distintos** no bestiário consolidado (97 definições novas de materiais reaproveitáveis).
- 10 biomas: cada um recebeu 25 novas criaturas, com 5 em cada nível.
- Arquivos anteriores preservados: 250 monstros e 713 itens originais mantidos sem modificação.

## Regras

- Fauna perto dos povoados tende a ser pequena ou defensiva; ameaça maior é mais distante e contextual.
- Humanos, elfos, anões, pequeninos e gnomos são os cinco povos jogáveis; goblins e orcs são criaturas hostis do catálogo de encontros e não raças jogáveis nesta proposta.
- O mundo decide espécie, posição, HP, dano, experiência e rolagens de saque; o narrador apenas descreve resultados autorizados.
- Saques não entram automaticamente no inventário. Cada extração exige a ação apropriada e ferramentas e condições válidas.
- A LUK pode afetar chances apenas pelo cálculo definido no backend; números deste arquivo são bases de balanceamento, não regras automaticamente ativas.
- Materiais básicos são reaproveitados por vários monstros (por exemplo, couro cru e tendão), evitando centenas de drops quase idênticos que quebrariam o mercado.
- Preços em cobres/bronze continuam baixos e precisam de ajuste em função da economia local (1 cobre = 1 bronze).
- **A economia atual não foi automaticamente expandida com compradores para os materiais novos; nenhuma venda desses itens deve ser presumida antes da integração.**
- Os modelos de missão existentes continuam intactos; acrescentar missões baseadas em novos IDs é uma etapa de integração separada.

## Integridade

- IDs únicos de monstros, saques e itens: aprovado.
- Todas as referências dos saques apontam para itens existentes: aprovado.
- Biomas, níveis e tamanhos de grupo: aprovado.
- Confronto exato dos 250 monstros originais e 713 itens existentes: aprovado.
- Índices por nível, bioma e tipo refeitos: aprovado.
- Teste com o backend real: **ainda não realizado**.

## Arquivos

- `Everreach_Bestiario_500_Monstros_Completo_v3.json`: base unificada.
- `Everreach_Expansao_250_Monstros_Novos_v3.json`: somente os 250 novos.
- `Everreach_Bestiario_500_Validacao_v3.json`: validação automatizada.
- `Everreach_TODOS_Datasets_Flora1500_Monstros500_v3.zip`: pacote com os outros datasets mais recentes e o bestiário atualizado.
