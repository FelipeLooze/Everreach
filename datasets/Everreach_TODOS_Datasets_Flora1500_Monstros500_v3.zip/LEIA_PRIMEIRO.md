# Everreach — pacote atualizado

Inclui os nove datasets mais recentes: bestiário 500, flora 1500, missões 430, economia 55 ofícios, personalidades 1000, aparências 2000, nomes de pessoas 4500, nomes de lugares 4000 e 5 povos/10 mestiçagens.

NOVO: 250 novos monstros, 750 saques e índices reconstruídos.

Os números mecânicos novos são propostas; é preciso adaptar o importador e revisar o balanceamento.

Leia `01_Bestiario/GUIA.md` antes da integração.
