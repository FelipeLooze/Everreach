# Everreach — Pacote consolidado v4

Versão mais recente, substitui os ZIPs anteriores.

- monstros: 500
- flora: 1500
- missoes: 430
- perfis_economia: 120
- mercadorias: 1000
- servicos: 150
- receitas: 500
- perfis_estoque: 250
- perfis_demanda: 200
- caracteristicas_personalidade: 1000
- aparencias: 2000
- nomes_pessoas: 4500
- nomes_lugares: 4000
- povos: 5
- combinacoes_mistas: 10

**Novidade:** economia v4 com 2.220 registros distribuídos em 6 blocos. Receitas e mercadorias requerem validação no backend.
